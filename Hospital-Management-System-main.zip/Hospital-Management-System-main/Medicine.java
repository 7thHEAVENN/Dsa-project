//pizza.java
package Hosptial;

class Medicine{
    String name,M_Pro ;                    // stores name of the Medicine
    int Mrp;    // variables to store the costs of medicine and property
    public Integer time_reqd;
                  

    public Medicine(String n, String Property, int mrp){
        name=n;
        M_Pro= Property;
        Mrp=mrp;
       
        
    }
}