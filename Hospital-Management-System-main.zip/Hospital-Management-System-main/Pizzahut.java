package Hosptial;

public class Pizzahut {
    
}
